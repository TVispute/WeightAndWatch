package com.example.shri.weight_and_watch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class DailyActivities extends AppCompatActivity {

    EditText morn,aft,eve,night;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_activities);

        morn=findViewById(R.id.morn);
        aft=findViewById(R.id.aft);
        eve=findViewById(R.id.eve);
        night=findViewById(R.id.night);
    }
}
