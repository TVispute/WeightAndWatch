package com.example.shri.weight_and_watch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class DietPlan extends AppCompatActivity {

    WebView wv;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_plan);
        wv=(WebView)findViewById(R.id.wv);
        b1=(Button)findViewById(R.id.b1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              wv.loadUrl("file:///android_asset/dietplan.html");
            }
        });
    }
}
