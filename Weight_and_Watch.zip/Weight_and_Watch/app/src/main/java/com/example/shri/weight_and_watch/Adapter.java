package com.example.shri.weight_and_watch;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;


import co.ceryle.fitgridview.FitGridAdapter;

class Adapter extends FitGridAdapter {

    private int[] drawables = {
            R.drawable.contact, R.drawable.frnd, R.drawable.dumb, R.drawable.food};

    private Context context;

    Adapter(Context context) {
        super(context, R.layout.grid_item);
        this.context = context;
    }

    @Override
    public void onBindView(final int position, View itemView) {
        ImageView iv = (ImageView) itemView.findViewById(R.id.grid_item_iv);
        iv.setImageResource(drawables[position]);

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Toast.makeText(context.getApplicationContext(), "Success", Toast.LENGTH_LONG).show();
                if (position == 0) {
                    Intent intentRegister = new Intent(context.getApplicationContext(), DailyActivities.class);
                    context.startActivity(intentRegister);

                }
            }

        });
    }

}
