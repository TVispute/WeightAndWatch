package com.example.shri.weight_and_watch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static java.lang.String.valueOf;

public class UserProfile extends AppCompatActivity {
    EditText height,weight,age;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        b1=findViewById(R.id.b1);
        height = findViewById(R.id.height);
        String a = valueOf((height.getText()));
        final Integer n = Integer.parseInt(a);

        weight = findViewById(R.id.weight);
        String b = valueOf((weight.getText()));
        final Integer n1 = Integer.parseInt(a);


        age=findViewById(R.id.age);

float bmi=n1/n*n;


b1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Toast.makeText(getApplicationContext(), "YOUR BMI IS " + bmi, Toast.LENGTH_LONG).show();

    }
});



    }
}
