package com.example.shri.weight_and_watch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ExercisePlan extends AppCompatActivity {
      Button wl,wg,preg,bp,d;
      TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_plan);
       wl=findViewById(R.id.wl);
        wg=findViewById(R.id.wg);
        preg=findViewById(R.id.preg);
        d=findViewById(R.id.d);
        bp=findViewById(R.id.bp);
        tv=findViewById(R.id.tv);
        wl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText("1. Plank:");
            }
        });
    }
}/* +
                    "Exercises For Weight Loss - PlankPinit\n" +
                    "\n" +
                    "\n" +
                    "Plank is one of the most basic moves that you can follow to keep yourself fit. It has so many benefits that you will love it for sure.\n" +
                    "\n" +
                    "How To Do It:\n" +
                    "\n" +
                    "1.Get down on the floor on your hands and the balls of your feet.\n" +
                    "2.Make sure your body is in a straight line and your hands are underneath your shoulders.\n" +
                    "3.Keep your abs tight and belly button sucked in.\n" +
                    "\n" +
                    "2. Jumping Jacks:\n" +
                    "Exercises For Weight Loss - Jumping JacksPinit\n" +
                    "\n" +
                    "Jumping Jacks are one of the best cardio moves that are very effective in incinerating fat from the entire body.\n" +
                    "\n" +
                    "\n" +
                    "How To Do It:\n" +
                    "\n" +
                    "1.Stand with your back erect and abs tight keep your feet together.\n" +
                    "2.Now jump and open your feet wide.\n" +
                    "3.At the same time lift your arms overhead.\n" +
                    "4.Jump again and come back to the starting position.\n" +
                    "\n" +
                    "3. Skipping:\n" +
                    "Exercises For Weight Loss - SkippingPinit\n" +
                    "Image: Shutterstock\n" +
                    "\n" +
                    "Skipping or rope jumping is a cardio exercise that can burn 300-400 calories in 45 minutes depending on your weight.\n" +
                    "\n" +
                    "How To Do It:\n" +
                    "\n" +
                    "1.Stand with your back erect and abs tight.\n" +
                    "2.Keep your feet together.\n" +
                    "3.Now jump off the ground a few inches letting the rope pass under your feet and bring it back up.\n" +
                    "4.If you do not have a rope, just jump up and down without the rope but keep moving your hands as if you are holding a rope.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "4. Cross -Trainer:\n" +
                    "Exercises For Weight Loss - Cross -TrainerPinit\n" +
                    "Image: Shutterstock\n" +
                    "\n" +
                    "Elliptical trainer or cross-trainer does not only burn a major amount of calories but also builds leg muscles and helps in shedding arm fat.\n" +
                    "\n" +
                    "How To Do It:\n" +
                    "\n" +
                    "\n" +
                    "Step on the peddles and get hold of the handlebars firmly.\n" +
                    "Now move your feet along the peddles as if you are stepping forward, it nearly imitates the walking motion.\n" +
                    "With every step, make sure you move handlebars also, one towards your chest and alternating the movement.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "5. Butt Kicks:\n" +
                    "Exercises For Weight Loss - Butt KicksPinit\n" +
                    "Image: Shutterstock\n" +
                    "\n" +
                    "Butt kicks are cardiovascular exercises. The difference between butt kicks and jogging is that in butt kicks you try to touch your butt alternatively with each leg. To increase the intensity, increase your speed.\n" +
                    "\n" +
                    "How To  Do It:\n" +
                    "\n" +
                    "\n" +
                    "Stand with your feet hip-width apart and keep your abs tight.\n" +
                    "Now start jogging on the spot with your calves kicking back and feet almost touching your butt.\n" +
                    "[ Video: Weight Loss Workout For Women ]\n" +
                    "\n" +
                    "6. Mountain Climbers:\n" +
                    "Exercises For Weight Loss - Mountain ClimbersPinit\n" +
                    "Image: Shutterstock\n" +
                    "\n" +
                    "Mountain climbers burn fat from the abdominal area and help in getting rid of love handles.\n" +
                    "\n" +
                    "How To Do It:\n" +
                    "\n" +
                    "Get into a plank.\n" +
                    "Bending one knee, place it slightly forward.\n" +
                    "Now start shifting your legs forward and backward by interchanging their positions.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "7. Plank Jacks:\n" +
                    "Exercises For Weight Loss - Plank JacksPinit\n" +
                    "Image: Shutterstock\n" +
                    "\n" +
                    "Plank Jacks are a cardio version of planks which give the benefit of both cardio and strengthening the core.\n" +
                    "\n" +
                    "How To Do It:\n" +
                    "\n" +
                    "Get into the plank and jump your legs open.\n" +
                    "Jump again and bring your feet together.\n" +
                    "Open and close is the movement you follow while your upper body remain stationary in plank.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "8. Push-Ups:\n" +
                    "Exercises For Weight Loss - Push-UpsPinit\n" +
                    "Image: Shutterstock\n" +
                    "\n" +
                    "Push-ups are amazingly effective for toning arms and strengthening the whole body.\n" +
                    "\n" +
                    "How To Do It:\n" +
                    "\n" +
                    "Get into plank.\n" +
                    "Now, bend your elbows as you lower yourself toward the floor.\n" +
                    "Press back up by straightening your arms.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "9. Triceps Push-ups:\n" +
                    "Exercises For Weight Loss - Triceps Push-upsPinit\n" +
                    "Image: Shutterstock\n" +
                    "\n" +
                    "We all detest those bingo wings. So, kill that tricep fat by doing triceps push-up.\n" +
                    "\n" +
                    "How To Do It:\n" +
                    "\n" +
                    "Get into the plank.\n" +
                    "Remain on your toes or put your knees down.\n" +
                    "Now press into the floor by pushing your elbows back.\n" +
                    "Straighten your arms and push back up.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "10. Spider Push-up:\n" +
                    "Exercises For Weight Loss - Spider Push-upPinit\n" +
                    "Image: Shutterstock\n" +
                    "\n" +
                    "These push-ups work your arms, shoulders, legs and glutes all at the same time.\n" +
                    "\n" +
                    "How To Do It:\n" +
                    "\n" +
                    "Get in the plank and put your right hand out beside your head and your right foot in line with that hand.\n" +
                    "Now, press down and as you push back up, get back into plank.\n" +
                    "Switch sides with every push-up.\n");
            }
        });

        wg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             wg.setText("1. Push-Ups:\n" +
                     "push ups everyday Pinit\n" +
                     "Image: Shutterstock\n" +
                     "\n" +
                     "Push-ups are one of the most effective forms of exercise as they do not require weights or any fancy machines. This exercise is ideal for gaining weight on the upper body as it works best when bigger muscles are worked upon.\n" +
                     "\n" +
                     "\n" +
                     "2. Low Intensity Aerobic Workout:\n" +
                     "Low Intensity Aerobic Workout Pinit\n" +
                     "Image: Shutterstock\n" +
                     "\n" +
                     "This form of exercise for weight gain involves breathing in oxygen and breathing out carbon dioxide in the process of performing low intensity workouts. It stimulates the appetite and enhances the metabolism, which leads to an increase in weight.\n" +
                     "\n" +
                     "3. Swimming:\n" +
                     "Swimming fast Pinit\n" +
                     "Image: Shutterstock\n" +
                     "\n" +
                     "This cardiovascular workout is effective in both weight gain as well as weight loss. When a person swims diligently, his appetite gets aggravated and he tends to consume a lot of food, which causes weight gain.\n" +
                     "\n" +
                     "4. Jogging:\n" +
                     "Running and jogging Pinit\n" +
                     "Image: Getty\n" +
                     "\n" +
                     "Jogging, like swimming, is a good cardiovascular exercise that has the ability to boost the person’s metabolism. This results in adding muscle mass to a lean body as a person develops the ability to digest heavy meals easily and add lots of proteins in the process.\n" +
                     "\n" +
                     "\n" +
                     "5. Lunges And Squats:\n" +
                     "Lunges and Squats Pinit\n" +
                     "Image: Shutterstock\n" +
                     "\n" +
                     "Lunges and squats are an excellent exercises to gain weight. They are an option when it comes to putting on weight around the quadriceps, the back and the calves. The area around the legs is the largest muscle zone and one can gain much weight if these lunges and squats are performed in sets.\n" +
                     "\n" +
                     " 6. Bench Press:\n" +
                     "bench press workout Pinit\n" +
                     "Image: Getty\n" +
                     "\n" +
                     "Exercises like the bench press are effective in increasing more weight around the inner and outer chest regions than on the shoulders and forearms. Inclined bench press and a few more modifications are known to bear better results. Two sets of ten each is ideal to gain weight in the focused area.\n" +
                     "\n" +
                     "7. Deadlifts:\n" +
                     "deadlifts exercises Pinit\n" +
                     "Image: Shutterstock\n" +
                     "\n" +
                     "Before practicing this exercise, one is required to understand the form as it involves the usage of heavy weights with the help of the arms, back and legs. It can be precarious hence one should practice it in the presence of a trainer. This workout helps in gaining weight promptly.\n" +
                     "\n" +
                     "8. Yoga:\n" +
                     "yoga Pinit\n" +
                     "Image: Shutterstock\n" +
                     "\n" +
                     "Yoga involves the enactment of poses with precision and correct pattern of breathing. This not just helps in gaining weight by reviving the appetite, it also relaxes the mind which indirectly helps in gaining weight. Some of the effective asanas that help in weight gain are Sarvang asana, vajra asana, bhujang asana and matsya Asana.\n" +
                     "\n" +
                     "[ Read: Simple Remedies For Weight Gain ]\n" +
                     "\n" +
                     "9. Pull-Ups:\n" +
                     "pull ups exercise Pinit\n" +
                     "Image: Getty\n" +
                     "\n" +
                     "This exercise is more effective when executed with a bar. It can be done anywhere and like push ups, this exercise is also a part of calisthenics. It helps in increasing the weight around the shoulder and chest area.\n" +
                     "\n" +
                     "\n" +
                     "10. Upright Barbell Rows And Dumbbell Shoulder Press:\n" +
                     "Upright Barbell Rows Pinit\n" +
                     "Image: Shutterstock\n" +
                     "\n" +
                     "These exercises are wonderful for gaining muscle mass in the upper body and help a thin body gain a good physique. These weight gain exercises have to be done repeatedly in sets and can be done at home as well.\n" +
                     "\n" +
                     "[ Read: Best Vigorous Exercises ]\n" +
                     "\n" +
                     "\n" +
                     "To gain weight, one is required to focus on muscle growth and development. These muscles thrive on exercises and food full of high calories. The above mentioned exercises to gain weight can be combined to form a complete workout. Keep in mind that results in gaining weight is possible when a person works out regularly as one cannot put on weight overnight.\n" +
                     "\n");
            }
        });

        preg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             preg.setText("Swimming\n" +
                     "Swimming and water aerobics may just be the perfect pregnancy workout. Why? In the water, you weigh less than you do on land, so you’ll feel lighter and more agile. A dip in the pool may also help relieve nausea, sciatic pain and puffy ankles. And because baby’s floating along with you, it’s gentle on your loosening joints and ligaments (your body’s natural response to pregnancy hormones).\n" +
                     "\n" +
                     "Just be careful walking on slippery pool sides, and step or slide into the water rather than diving or jumping in. Your growing baby isn’t equipped to handle the bubbles that form inside the body when you quickly change altitudes under the pressure of the water (it’s why scuba diving is a big no-no). And as your pregnancy progresses, your center of gravity will likely be off too. All that means the impact of diving isn't worth the potential risk.\n" +
                     "\n" +
                     "Walking\n" +
                     "There’s no easier exercise to fit into your busy schedule than walking … and it’s a workout you can continue right up until your delivery date (and even on D-day if you’re anxious to help along the contractions). What’s more, you don’t need any special equipment or a gym membership to participate — just some good sneakers.\n" +
                     "\n" +
                     "Running\n" +
                     "Want to go a little faster? Experienced runners can stay on track during pregnancy. Stick to level terrain (or a treadmill) and never overdo it (loose ligaments and joints during pregnancy can make jogging harder on your knees — and you more prone to injury).\n" +
                     "\n" +
                     "Ellipticals and stair climbers\n" +
                     "Both ellipticals and stair climbers are good bets during pregnancy. Adjust speed, incline and tension to a level that’s comfortable for you. Keep in mind that as your pregnancy progresses, you may have a harder time with resistance (or not; listen to your body) and need to pay closer attention to where you step to avoid stumbles.\n" +
                     "\n" +
                     "Group dance or aerobics classes\n" +
                     "Low-impact aerobics and dance workout classes like Zumba are a great way to increase your heart rate and get the endorphins flowing if you’re a newbie exerciser. As your abdomen expands, avoid any activities that require careful balance. If you’re an experienced athlete, listen to your body, avoid jumping or high-impact movements, and never exercise to the point of exhaustion. If you’re new to exercise, opt for the water version of aerobics, which is ideal for the expecting set.\n" +
                     "\n" +
                     "Indoor cycling\n" +
                     "If you’ve been spinning for at least six months before pregnancy, you should be able to continue as long as you tone down the workout. Indoor cycling can be great exercise, as it lets you pedal at your own pace without the risk of falling or putting pressure on your ankle and knee joints.\n" +
                     "\n" +
                     "Make sure your instructor knows you’re expecting, and sit out sprints if you feel overheated or exhausted at any point. Also adjust the handlebars so you’re more upright and not leaning forward to avoid adding pressure on your lower back. Stay seated during hill climbs, since standing is too intense for moms-to-be. If spinning seems exhausting, take a break until after baby’s born.\n" +
                     "\n" +
                     "Kickboxing\n" +
                     "Many expecting kickboxers find they aren’t quite as graceful or quick as pre-pregnancy, but if you still feel comfortable getting your kicks in the ring and you have plenty of experience, it’s okay to continue now. To avoid accidentally getting jabbed in the belly, leave two lengths of space between you and other kickboxers, and let everyone in the class know you’re pregnant (or find a class specifically for pregnant moms).\n" +
                     "\n" +
                     "High-intensity interval training workouts (HIIT)\n" +
                     "High-intensity interval training definitely isn’t for every expecting woman. The workouts, which involve more hardcore moves to get your heart rate up followed by periods of rest, are simply too intense to begin for the first time when you’re expecting.\n" +
                     "\n" +
                     "However if you’ve been at HIIT for a while and get the green light from your practitioner, classes can be safe with modifications from your instructor (avoid jumping, jarring movements and quick changes in direction, and choose lower weights than you might usually pick up). Stop if you’re feeling out of breath or exhausted, drink lots of water, and be especially careful with any exercises involving balance.\n" +
                     "\n" +
                     "Some outdoor sports\n" +
                     "Now’s not the time to take on a new sport, but if you’re an experienced athlete, you should be able to continue the following outdoor sports given your doctor’s approval and a few modifications:\n" +
                     "\n" +
                     "Hiking: Avoid uneven terrain (especially later in pregnancy, when your belly can block your view of pebbles in your path), high altitudes and slippery conditions.\n" +
                     "Biking: If you're an avid outdoor cycler, talk to your doctor about whether it's safe to continue biking outside after getting pregnant (and if, at some point, you should stop). The extra weight of your baby belly can affect your balance, and you don’t want to risk toppling over when baby is on board. If you do get the green light, wear a helmet, skip bumpy surfaces, and avoid wet pavement and roads with tight curves.\n" +
                     "Ice skating, horseback riding and in-line skating: You can probably keep these activities up early in pregnancy, but you’ll have to give them up later on due to balance issues.\n" +
                     "Cross-country skiing and snowshoeing: These are both fine as long as you’re extra careful about tripping. Just know that downhill skiing and snowboarding are off-limits for now because the risk of a serious fall or collision is too great.\n" +
                     "What Are the Best Strength and Flexibility Exercises I Can Do While I'm Pregnant?\n" +
                     "Strength workouts help maintain and build your muscles. Stronger and more flexible muscles, in turn, help you to bear the weight you gain throughout your pregnancy and protect your joints from injuries as your ligaments relax. Here are the best strengthening exercises for pregnant women:\n" +
                     "\n" +
                     "Weight lifting\n" +
                     "Lifting weights is a good way to increase your muscle tone when you’re expecting — just opt for more reps (i.e. 12 to 15 in a set) using a lower weight than usual. You might also want to switch to machines, which limit your range of motion to reduce any chance of injury. Try to skip isometric movements — exercises where you hold still in a particular position — because if you accidentally forget to breathe (it’s a common mistake!), you could easily become lightheaded. Use light weights with multiple repetitions instead. And don’t forget to stretch when you're done!\n" +
                     "\n" +
                     "Ask your practitioner if you need to make modifications to your TRX routine, and skip the Crossfit unless you’ve been at it for years and get the okay from your doctor.\n" +
                     "\n" +
                     "Pilates\n" +
                     "A pregnancy-appropriate Pilates routine focuses mainly on strengthening your core and lengthening your muscles with low- to no-impact, which will help ease backaches and improve your posture as well as your flexibility (and that all comes in handy during labor). Look for a class tailored specifically to pregnant women or let your instructor know you’re expecting to avoid moves that overstretch or otherwise aren’t compatible with pregnancy.\n" +
                     "\n" +
                     "Barre\n" +
                     "Barre classes — a mix of Pilates, yoga and ballet-inspired moves — are excellent for expecting women because they involve strengthening your lower body and core without much jumping. They also involve balance exercises, which help keep you stable as your baby bump throws off your balance. Be sure to let your instructor know you’re pregnant before you begin class so he or she can give you modifications for the few exercises that can put extra strain on your abdomen.\n" +
                     "\n" +
                     "Yoga\n" +
                     "Prenatal yoga is another ideal workout for moms-to-be: It encourages relaxation, flexibility, focus and deep breathing — all great preparation for the marathon of birth. Look for a class specifically tailored to pregnant women, or ask your regular yoga instructor to modify the poses so they’re safe for you (that usually means avoiding deep back bends as well as full inversions like handstands and headstands because of potential blood pressure issues). Avoid Bikram (hot) yoga, since you need to pass on exercises that heat you up too much.\n" +
                     "\n" +
                     "Tai Chi  \n" +
                     "This ancient form of meditation involves slow movements that allow even the least flexible to strengthen their bodies without risk of injury. If you’re comfortable with it and have experience, it’s fine to continue tai chi now. Just look for pregnancy-specific classes or stick to exercises you know well, and be extra cautious with those involving balance.\n");
            }
        });
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.setText("Walking — Because anyone can do it almost anywhere, walking is the most popular exercise and one we highly recommend for people with diabetes. Thirty minutes to one hour of brisk walking, three times each week is a great, easy way to increase your physical activity.\n" +
                        "\n" +
                        "\n" +
                        "Tai Chi —This Chinese form of exercise uses slow, smooth body movements to relax the mind and body. In 2009, researchers at the University of Florida studied 62 Korean women assigned to one of two groups—a control group and an exercise group that began a regular practice of Tai Chi. Those who completed the tai chi sessions showed significant improvement in blood sugar control. They also reported increased vitality, energy and mental health.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Yoga — A traditional form of exercise, yoga incorporates fluid movements that build flexibility, strength and balance. It is helpful for people with a variety of chronic conditions, including diabetes. It lowers stress and improves nerve function, which leads to an increased state of mental health and wellness. According to the ADA, yoga may improve blood glucose levels due to improved muscle mass.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Dancing —Dancing is not only great for your body. The mental work to remember dance steps and sequences actually boosts brain power and improves memory.  For those with diabetes, it is a fun and exciting way to increase physical activity, promote weight loss, improve flexibility, lower blood sugar and reduce stress. Chair dancing, which incorporates the use of a chair to support people with limited physical abilities, makes dancing an option for many people. In just 30 minutes, a 150-pound adult can burn up to 150 calories.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Swimming — Swimming stretches and relaxes your muscles and doesn’t put pressure on your joints, which is great for people with diabetes. For those with diabetes or at risk for developing diabetes, studies show it improves cholesterol levels, burns calories and lowers stress levels. To get the most benefit from swimming, we recommend that you swim at least three times a week for at least ten minutes and gradually increase the length of the workout. Make sure to have a snack and monitor blood sugars. Lastly, let the lifeguard know that you have diabetes before you get in the pool.\n" +
                        "\n");
            }
        });

        bp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bp.setText("1. Lose extra pounds and watch your waistline\n" +
                        "Blood pressure often increases as weight increases. Being overweight also can cause disrupted breathing while you sleep (sleep apnea), which further raises your blood pressure.\n" +
                        "\n" +
                        "Weight loss is one of the most effective lifestyle changes for controlling blood pressure. Losing even a small amount of weight if you're overweight or obese can help reduce your blood pressure. In general, you may reduce your blood pressure by about 1 millimeter of mercury (mm Hg) with each kilogram (about 2.2 pounds) of weight you lose.\n" +
                        "\n" +
                        "Besides shedding pounds, you generally should also keep an eye on your waistline. Carrying too much weight around your waist can put you at greater risk of high blood pressure.\n" +
                        "\n" +
                        "In general:\n" +
                        "\n" +
                        "Men are at risk if their waist measurement is greater than 40 inches (102 centimeters).\n" +
                        "Women are at risk if their waist measurement is greater than 35 inches (89 centimeters).\n" +
                        "These numbers vary among ethnic groups. Ask your doctor about a healthy waist measurement for you.\n" +
                        "\n" +
                        "2. Exercise regularly\n" +
                        "Regular physical activity — such as 150 minutes a week, or about 30 minutes most days of the week — can lower your blood pressure by about 5 to 8 mm Hg if you have high blood pressure. It's important to be consistent because if you stop exercising, your blood pressure can rise again.\n" +
                        "\n" +
                        "If you have elevated blood pressure, exercise can help you avoid developing hypertension. If you already have hypertension, regular physical activity can bring your blood pressure down to safer levels.\n" +
                        "\n" +
                        "Some examples of aerobic exercise you may try to lower blood pressure include walking, jogging, cycling, swimming or dancing. You can also try high-intensity interval training, which involves alternating short bursts of intense activity with subsequent recovery periods of lighter activity. Strength training also can help reduce blood pressure. Aim to include strength training exercises at least two days a week. Talk to your doctor about developing an exercise program.\n" +
                        "\n" +
                        "3. Eat a healthy diet\n" +
                        "Eating a diet that is rich in whole grains, fruits, vegetables and low-fat dairy products and skimps on saturated fat and cholesterol can lower your blood pressure by up to 11 mm Hg if you have high blood pressure. This eating plan is known as the Dietary Approaches to Stop Hypertension (DASH) diet.\n" +
                        "\n" +
                        "It isn't easy to change your eating habits, but with these tips, you can adopt a healthy diet:\n" +
                        "\n" +
                        "Keep a food diary. Writing down what you eat, even for just a week, can shed surprising light on your true eating habits. Monitor what you eat, how much, when and why.\n" +
                        "Consider boosting potassium. Potassium can lessen the effects of sodium on blood pressure. The best source of potassium is food, such as fruits and vegetables, rather than supplements. Talk to your doctor about the potassium level that's best for you.\n" +
                        "Be a smart shopper. Read food labels when you shop and stick to your healthy-eating plan when you're dining out, too.\n" +
                        "4. Reduce sodium in your diet\n" +
                        "Even a small reduction in the sodium in your diet can improve your heart health and reduce blood pressure by about 5 to 6 mm Hg if you have high blood pressure.\n" +
                        "\n" +
                        "The effect of sodium intake on blood pressure varies among groups of people. In general, limit sodium to 2,300 milligrams (mg) a day or less. However, a lower sodium intake — 1,500 mg a day or less — is ideal for most adults.\n" +
                        "\n" +
                        "To decrease sodium in your diet, consider these tips:\n" +
                        "\n" +
                        "Read food labels. If possible, choose low-sodium alternatives of the foods and beverages you normally buy.\n" +
                        "Eat fewer processed foods. Only a small amount of sodium occurs naturally in foods. Most sodium is added during processing.\n" +
                        "Don't add salt. Just 1 level teaspoon of salt has 2,300 mg of sodium. Use herbs or spices to add flavor to your food.\n" +
                        "Ease into it. If you don't feel you can drastically reduce the sodium in your diet suddenly, cut back gradually. Your palate will adjust over time.\n" +
                        "5. Limit the amount of alcohol you drink\n" +
                        "Alcohol can be both good and bad for your health. By drinking alcohol only in moderation — generally one drink a day for women, or two a day for men — you can potentially lower your blood pressure by about 4 mm Hg. One drink equals 12 ounces of beer, five ounces of wine or 1.5 ounces of 80-proof liquor.\n" +
                        "\n" +
                        "But that protective effect is lost if you drink too much alcohol.\n" +
                        "\n" +
                        "Drinking more than moderate amounts of alcohol can actually raise blood pressure by several points. It can also reduce the effectiveness of blood pressure medications.\n" +
                        "\n" +
                        "6. Quit smoking\n" +
                        "Each cigarette you smoke increases your blood pressure for many minutes after you finish. Stopping smoking helps your blood pressure return to normal. Quitting smoking can reduce your risk of heart disease and improve your overall health. People who quit smoking may live longer than people who never quit smoking.\n" +
                        "\n" +
                        "7. Cut back on caffeine\n" +
                        "The role caffeine plays in blood pressure is still debated. Caffeine can raise blood pressure up to 10 mm Hg in people who rarely consume it. But people who drink coffee regularly may experience little or no effect on their blood pressure.\n" +
                        "\n" +
                        "Although the long-term effects of caffeine on blood pressure aren't clear, it's possible blood pressure may slightly increase.\n" +
                        "\n" +
                        "To see if caffeine raises your blood pressure, check your pressure within 30 minutes of drinking a caffeinated beverage. If your blood pressure increases by 5 to 10 mm Hg, you may be sensitive to the blood pressure raising effects of caffeine. Talk to your doctor about the effects of caffeine on your blood pressure.\n" +
                        "\n" +
                        "8. Reduce your stress\n" +
                        "Chronic stress may contribute to high blood pressure. More research is needed to determine the effects of chronic stress on blood pressure. Occasional stress also can contribute to high blood pressure if you react to stress by eating unhealthy food, drinking alcohol or smoking.\n" +
                        "\n" +
                        "Take some time to think about what causes you to feel stressed, such as work, family, finances or illness. Once you know what's causing your stress, consider how you can eliminate or reduce stress.\n" +
                        "\n" +
                        "If you can't eliminate all of your stressors, you can at least cope with them in a healthier way. Try to:\n" +
                        "\n" +
                        "Change your expectations. For example, plan your day and focus on your priorities. Avoid trying to do too much and learn to say no. Understand there are some things you can't change or control, but you can focus on how you react to them.\n" +
                        "Focus on issues you can control and make plans to solve them. If you are having an issue at work, try talking to your manager. If you are having a conflict with your kids or spouse, take steps to resolve it.\n" +
                        "Avoid stress triggers. Try to avoid triggers when you can. For example, if rush-hour traffic on the way to work causes stress, try leaving earlier in the morning, or take public transportation. Avoid people who cause you stress if possible.\n" +
                        "Make time to relax and to do activities you enjoy. Take time each day to sit quietly and breathe deeply. Make time for enjoyable activities or hobbies in your schedule, such as taking a walk, cooking or volunteering.\n" +
                        "Practice gratitude. Expressing gratitude to others can help reduce your stress.\n" +
                        "9. Monitor your blood pressure at home and see your doctor regularly\n" +
                        "Home monitoring can help you keep tabs on your blood pressure, make certain your lifestyle changes are working, and alert you and your doctor to potential health complications. Blood pressure monitors are available widely and without a prescription. Talk to your doctor about home monitoring before you get started.\n" +
                        "\n" +
                        "Regular visits with your doctor are also key to controlling your blood pressure. If your blood pressure is well-controlled, check with your doctor about how often you need to check it. Your doctor may suggest checking it daily or less often. If you're making any changes in your medications or other treatments, your doctor may recommend you check your blood pressure starting two weeks after treatment changes and a week before your next appointment.\n" +
                        "\n" +
                        "10. Get support\n" +
                        "Supportive family and friends can help improve your health. They may encourage you to take care of yourself, drive you to the doctor's office or embark on an exercise program with you to keep your blood pressure low.\n" +
                        "\n" +
                        "If you find you need support beyond your family and friends, consider joining a support group. This may put you in touch with people who can give you an emotional or morale boost and who can offer practical tips to cope with your condition.\n" +
                        "\n");
            }
        });
    }*/

